# What I have changed 📝
<!--Put in here anything you have changed, perhaps in bullet points.
E.g.
 - ⭐ Increased efficiency of Class.function() method
 - ✅ Added function() method to Class

Please make sure that you have contributed more than just a few lines
or a bit of formating.-->

<br/>

## Possible issues ⛔
<!--Anything that might go wrong or could be improved? We are here to help.-->

## Additional notes ⭐
<!--Anything else you want to say.-->
