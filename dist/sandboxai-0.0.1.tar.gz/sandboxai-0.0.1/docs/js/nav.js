// Copy and paste text from "templates/nav.html"
document.write(`
<nav id="nav">
	<a href="">
		<h1>easyNeuron</h1>
	</a>
	<div>
		<a href="/easyneuron/">Home</a>
		<a href="/easyneuron/docs/">Docs</a>
		<a href="/support/">Support Us</a>
	</div>
</nav>
`);
