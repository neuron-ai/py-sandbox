# Security Policy

## Supported Versions

There are currently no versions available. This is not yet production ready. Please do not use yet.

| Version | Supported          |
| ------- | ------------------ |
| | |

## Reporting a Vulnerability

Please send an email describing your issue to `neuronai.team@gmail.com`. There, it should be read within 7 working days and a response will be sent confirming whether the advisory should be taken up or not. We will do our best to fix the error, if applicable.
